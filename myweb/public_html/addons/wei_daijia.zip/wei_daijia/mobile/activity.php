<?php
include $this -> template('activity');
?>