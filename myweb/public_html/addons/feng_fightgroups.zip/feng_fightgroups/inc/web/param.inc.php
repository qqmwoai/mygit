<?php
		$tag = random(32);
		global $_GPC;
		load()->func('tpl');
		include $this->template('web/param');
?>